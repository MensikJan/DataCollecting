﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2.Iterator
{
    public class ValueIterator : IIterator
    {
        private List<Value.Item> data;
        private int position;
        public ValueIterator(List<Value.Item> data)
        {
            this.data = data;
            position = 0;
        }
       

        public Value.Item CurrentItem()
        {
            return data[position];
        }

        public void First()
        {
             position = 0; 
        }

        public bool IsDone()
        {
            return position >= data.Count;
        }

        public Value.Item Next()
        {
            return data[position++];
        }
    }
}

