﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApplication2.Iterator
{
    public interface IIterator
    {
        void First();
        Value.Item Next();
        bool IsDone();
        Value.Item CurrentItem();
    }
}
