﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newtonsoft;
using Newtonsoft.Json;
using System.Diagnostics;
using MySql.Data;
using MySql;
using MySql.Data.MySqlClient;
using System.Xml;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using WebApplication2.Iterator;
using System.Web.Services;
using System.Web.UI.DataVisualization.Charting;

namespace WebApplication2
 
{
    public partial class WebForm1 : System.Web.UI.Page
    {

       

        MySqlConnection connection;
        protected void Page_Load(object sender, EventArgs e)
        {

       
            /* if (!IsPostBack)
             {
                 CheckMysqlConnection();
             }*/
            string json = String.Empty;
            Context.Request.InputStream.Position = 0;
            using (var reader = new StreamReader(Context.Request.InputStream))
            {
                json = reader.ReadToEnd();
            }
            
            //for test
            if (json != "")
            {

                 
                Value objekt = new Value();
                try
                { // zmena #################################################################################

                    Value test = JsonConvert.DeserializeObject<Value>(json);
                    /*  // Debug.WriteLine(" bla bla " + test.data[0].portValue);
                       Debug.WriteLine(" bla bla " + test.data[0].portName);
                      ICreate val = test;

                      IIterator valIterator = val.CreateIterator();
                      UseIterator(valIterator);
                          //xUploadToMysqlDatabase();
                      */

                    foreach (Value.Item jsonobj in test.data)
                    {
                        MySQLUtil.getInstance().UploadToMysqlDatabase(jsonobj);
                    }
                    
                } catch (Exception ex){ Debug.WriteLine(json);
                    Debug.WriteLine(ex);
                }
                
                
              


            }
          
            

        }
        public static void UseIterator(IIterator iterate) {
            iterate.First();
            while (!iterate.IsDone()) {
                //Debug.WriteLine("vypiš!!!! " + iterate.Next());
                Value neco = new Value();
               
               // UploadToMysqlDatabase();
            }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            String portId = TextBox1.Text;
            String portName = DropDownList1.Text;

            // Chart1.DataSource=MySQLUtil.getInstance().DownloadFromMysqlDatabase("50579267");http://localhost:63928/WebForm1.aspx.cs
            DataTable table = new DataTable();
            table = MySQLUtil.getInstance().DownloadFromMysqlDatabase(portId, portName);
            GridView1.DataSource = table;


            GridView1.DataBind();

            Chart1.DataSource = table;
            Chart1.Series["Series1"].XValueMember = "portTime";
            Chart1.Series["Series1"].YValueMembers = "portValue";
            Chart1.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = false;
            Chart1.Series["Series1"].IsValueShownAsLabel = false;
            Chart1.DataBind();
            /*foreach (Tuple a in temp1) {
                TextBox2.Text = TextBox2.Text + a.ToString();
                Debug.WriteLine(a.ToString());
            }*/



            //Debug.WriteLine(temp1);
            //Debug.WriteLine("projde a tlacitko udela pokazde refresh");

        }

        [WebMethod()]
        public static String ajaxDBNumber()
        {
            int total = MySQLUtil.getInstance().getDBRecords();
            
            return total.ToString();

        }

        
    }

}