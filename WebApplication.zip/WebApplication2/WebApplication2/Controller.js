﻿$(document).ready(function () {
    getRecordAjax();

    function getRecordAjax(){
        $.ajax({
            type: "POST",
            url: "WebForm1.aspx/ajaxDBNumber",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                $("#Label3").text("Počet záznamů: " + data.d);
            },

            error: function () { }
        });
        return false;
    }

    setTimeout(function () {
        getRecordAjax();
    }, 15000);
});