﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MySql.Data;
using System.Diagnostics;
using MySql;
using MySql.Data.MySqlClient;
using System.Data;
using System.Collections;

namespace WebApplication2
{
	public class MySQLUtil : WebForm1
	{
        private static string CONNECTION_STRING = @"Server=localhost;Database=ev3;Uid=root;Pwd=root;";
        private static MySQLUtil instance;
        private MySqlConnection connection = null;
        private MySqlConnection connection2 = null;
        private MySqlConnection connection3 = null;
        private MySQLUtil() { }

        public static MySQLUtil getInstance()
        {
            if(instance == null)
            {
                instance = new MySQLUtil();
            }
            return instance;
        }

        public void UploadToMysqlDatabase(Value.Item objekt)
        {
            
            using (connection = new MySqlConnection(CONNECTION_STRING))
            {

                connection.Open();
                
                MySqlCommand cmd = new MySqlCommand();
                cmd = connection.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "INSERT INTO `robot`(`portId`, `portTime`, `portName`, `portValue`) VALUES(" + objekt.portId + ", '" + objekt.portTime + "','" + objekt.portName + "', " + objekt.portValue + ")";
                
                cmd.ExecuteNonQuery();


            }
        }
        public DataTable DownloadFromMysqlDatabase(string portId,string portName) {
           

            connection2 = new MySqlConnection(CONNECTION_STRING);
            MySqlCommand cmd = new MySqlCommand("SELECT portTime,portValue FROM `robot` WHERE `portId`='" + portId + "' AND `portName`='"+portName+"'  ORDER BY portTime;", connection2);
            connection2.Open();
            DataTable dataTable = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);

            da.Fill(dataTable);
            
            connection2.Close();

            
            return dataTable;

        }
           
        public int getDBRecords() {
            connection3 = new MySqlConnection(CONNECTION_STRING);
            MySqlCommand cmd = new MySqlCommand("SELECT COUNT(id) FROM `robot`;", connection3);
            connection3.Open();
            int total = Convert.ToInt32(cmd.ExecuteScalar());
            connection3.Close();
            return total;
        }


        
        }
    }
