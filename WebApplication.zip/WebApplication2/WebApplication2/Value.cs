﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApplication2.Iterator;

namespace WebApplication2
{
    public class Value : ICreate
    {
        public List<Item> data;
        public class Item
        {
            public string portId;
            public string portName;
            public string portTime;
            public double portValue;
        }

        public IIterator CreateIterator() {
            return new ValueIterator(data);
        }

    }
}