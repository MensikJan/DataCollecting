﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace insys
{
    class Value
    {
        public string portId;
        public string portName;
        public string portTime;
        public string portValue;
    }
}
