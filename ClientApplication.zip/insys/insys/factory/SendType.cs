﻿namespace insys.factory
{
    abstract public class SendType
    {
        private string adress;
        private string text;
        abstract public void send();

        public void setAdress(string adress)
        {
            this.adress = adress;
        }
        public string getAdress()
        {
            return this.adress;
        }

        public string getText()
        {
            return this.text;
        }
        public void setText(string text)
        {
            this.text = text;
        }
    }
}