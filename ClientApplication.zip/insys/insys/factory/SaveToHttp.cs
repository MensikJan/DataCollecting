﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;

namespace insys.factory
{
    public class SaveToHttp : SendType
    {
        public override void send() {
            try
            {
                System.Net.HttpWebRequest request = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(getAdress());

                request.Method = "POST";
                request.ContentType = "application/json";
                request.ContentLength = getText().Length;

                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamWriter.Write(getText());
                    streamWriter.Close();

                    var httpResponse = (HttpWebResponse)request.GetResponse();
                    using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                    {
                        var result = streamReader.ReadToEnd();
                    }
                }
            }
            catch (Exception ex){
                Debug.WriteLine("Chyba při odesílání na adresu : "+ex);
            }
        }
    }
}