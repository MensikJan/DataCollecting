﻿using System;
using System.Diagnostics;
using System.IO;

namespace insys.factory
{
    internal class SaveToFile : SendType
    {
        public override void send()
        {
            try
            {
                System.IO.StreamWriter Ev3_Data = new StreamWriter(@getAdress(), true);
                Ev3_Data.WriteLine(getText());
                Ev3_Data.Close();
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Chyba při zápisu do souboru : "+ex);
            }
        }
    }
}