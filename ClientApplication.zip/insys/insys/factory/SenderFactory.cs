﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace insys.factory
{
     class SenderFactory
    {
        public SendType createType(bool type) {
            SendType typ = null;

            if (type == true) {
                typ = new SaveToHttp();
            } else{
                typ = new SaveToFile();
            }
            return typ;
        } 
    }
}
