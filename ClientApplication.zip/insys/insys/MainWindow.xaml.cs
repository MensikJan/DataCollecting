﻿using Lego.Ev3.Core;
using Lego.Ev3.Desktop;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Newtonsoft;
using System.Net;
using System.Management;
using System.Text.RegularExpressions;
using insys.factory;

namespace insys
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
  
    public partial class MainWindow : Window
    {
        private Brick brick;
        
        public Boolean record = false;
        public Boolean record2 = false;
        public Boolean record3 = false;
        public Boolean record4 = false;
        public Boolean recordA = false;
        public Boolean recordB = false;
        public Boolean recordC = false;
        public Boolean recordD = false;

        Value portOne = new Value();
        Value portTwo = new Value();
        Value portThree = new Value();
        Value portFour = new Value();
        Value portA = new Value();
        Value portB = new Value();
        Value portC = new Value();
        Value portD = new Value();
        public Boolean target = true;
        string[] ports = SerialPort.GetPortNames();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            string portik = GetPortForBHDevice();
            foreach (string s in ports) {
                if (portik == s)
                cPorts.Items.Add(s);
            }            
        }

        void OnBrickChanged(object sender, BrickChangedEventArgs e)
        {
            BlockOne.Text = e.Ports[InputPort.One].SIValue.ToString();
            BlockTwo.Text = e.Ports[InputPort.Two].SIValue.ToString();
            BlockThree.Text = e.Ports[InputPort.Three].SIValue.ToString();
            BlockFour.Text = e.Ports[InputPort.Four].SIValue.ToString();
            BlockA.Text = e.Ports[InputPort.A].SIValue.ToString();
            BlockB.Text = e.Ports[InputPort.B].SIValue.ToString();
            BlockC.Text = e.Ports[InputPort.C].SIValue.ToString();
            BlockD.Text = e.Ports[InputPort.D].SIValue.ToString();
           
            recording();

                
        }

/// //////////////////////////////////RECORDING AND SENDING/////////////////////////////////////////

        private void recording()
        {
            string json = "{'data':[";
            
            if (portOne.portName != null && portOne.portValue != null) { json += Newtonsoft.Json.JsonConvert.SerializeObject(portOne) + ","; } // opravit aby nevracelo taky prázdný dictionarry && !portOne.portValue.TryGetValue(????) nebo nějak tak
            if (portTwo.portName != null && portTwo.portValue != null) { json += Newtonsoft.Json.JsonConvert.SerializeObject(portTwo) + ","; }
            if (portThree.portName != null && portThree.portValue != null) { json += Newtonsoft.Json.JsonConvert.SerializeObject(portThree) + ","; }
            if (portFour.portName != null && portFour.portValue != null) { json += Newtonsoft.Json.JsonConvert.SerializeObject(portFour) + ","; }
            if (portA.portName != null && portA.portValue != null) { json += Newtonsoft.Json.JsonConvert.SerializeObject(portA) + ","; }
            if (portB.portName != null && portB.portValue != null) { json += Newtonsoft.Json.JsonConvert.SerializeObject(portB) + ","; }
            if (portC.portName != null && portC.portValue != null) { json += Newtonsoft.Json.JsonConvert.SerializeObject(portC) + ","; }
            if (portD.portName != null && portD.portValue != null) { json += Newtonsoft.Json.JsonConvert.SerializeObject(portD)+","; }
            json = json.Remove(json.Length - 1);
            json += "]}";

            if (json != "{'data':]}") {
                // Debug.WriteLine("ubuntu jede : " + json);
                SenderFactory factory = new SenderFactory();
                SendType sender = factory.createType(target);
                sender.setAdress(AdressBox.Text);
                sender.setText(json);
                sender.send();
            }else{
                return;
            }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        }

        private void Window_Unloaded(object sender, RoutedEventArgs e)
        {
            brick.Disconnect();

        }
        

        protected override void OnKeyUp(KeyEventArgs e)
        {
            var a = e.Key;
        }

        private void stopButton_Click(object sender, RoutedEventArgs e)
        {
            record = false;
            BlockOne.Foreground = Brushes.Black;
        }

        private void zaznamButton_Click(object sender, RoutedEventArgs e) // při druhém kliku na záznam hází error PS: zkontrolovat tlačítko STOP
        {
            record = true;
            /* sw1.WriteLine("");
             sw1.WriteLine("PortOne: ");*/
            portOne.portName = "PortOne";
            brick.BrickChanged += BrickReader;
        }

        void BrickReader(object sender, BrickChangedEventArgs e)
        {
            if (record == true)
            {
        
                BlockOne.Foreground= Brushes.Red;
                portOne.portTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                portOne.portValue = BlockOne.Text;
                //portOne.portValue.Add(DateTime.Now, BlockOne.Text);
                /*sw1.Write(BlockOne.Text + "|");
                sw1.Flush();*/
            }


        }

        void BrickReader2(object sender, BrickChangedEventArgs e)
        {
            if (record2 == true)
            {
                BlockTwo.Foreground = Brushes.Red;
                portTwo.portTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                portTwo.portValue = BlockTwo.Text;
                //portTwo.portValue.Add(DateTime.Now, BlockTwo.Text);
                /*sw2.Write(BlockTwo.Text + "|");
                sw2.Flush();*/
            }


        }
        void BrickReader3(object sender, BrickChangedEventArgs e)
        {
            if (record3 == true)
            {
                BlockThree.Foreground = Brushes.Red;
                portThree.portTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                portThree.portValue = BlockThree.Text;
                //portThree.portValue.Add(DateTime.Now, BlockThree.Text); // pro posílání array
                /*sw3.Write(BlockThree.Text + "|");
                sw3.Flush();*/
            }


        }
        void BrickReader4(object sender, BrickChangedEventArgs e)
        {
            if (record4 == true)
            {
                BlockFour.Foreground = Brushes.Red;
                portFour.portTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                portFour.portValue = BlockFour.Text;
                //portFour.portValue.Add(DateTime.Now, BlockFour.Text);
                /*sw4.Write(BlockFour.Text + "|");
                sw4.Flush();*/
            }


        }
        void BrickReaderA(object sender, BrickChangedEventArgs e)
        {
            if (recordA == true)
            {
                BlockA.Foreground = Brushes.Red;
                portA.portTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                portA.portValue = BlockA.Text;
                //portA.portValue.Add(DateTime.Now, BlockA.Text);
                /*swA.Write(BlockA.Text + "|");
                swA.Flush();*/
            }


        }
        void BrickReaderB(object sender, BrickChangedEventArgs e)
        {
            if (recordB == true)
            {
                BlockB.Foreground = Brushes.Red;
                portB.portTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                portB.portValue = BlockB.Text;

                //portB.portValue.Add(DateTime.Now, BlockB.Text);
                /*swB.Write(BlockB.Text + "|");
                swB.Flush();*/
            }


        }
        void BrickReaderC(object sender, BrickChangedEventArgs e)
        {
            if (recordC == true)
            {
                BlockC.Foreground = Brushes.Red;
                portC.portTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                portC.portValue = BlockC.Text;
                //portC.portValue.Add(DateTime.Now, BlockC.Text);
                /*swC.Write(BlockC.Text + "|");
                swC.Flush();*/
            }


        }
        void BrickReaderD(object sender, BrickChangedEventArgs e)
        {
            if (recordD == true)
            {
                BlockD.Foreground = Brushes.Red;
                portD.portTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                portD.portValue = BlockD.Text;
                //portD.portValue.Add(DateTime.Now, BlockD.Text);
                /*swD.Write(BlockD.Text + "|");
                swD.Flush();*/
            }


        }



        private async void connectButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                
                //BluetoothCommunication b = new BluetoothCommunication(cPorts.SelectedItem.ToString());
                
                BluetoothCommunication b = new BluetoothCommunication(cPorts.SelectedItem.ToString());
                brick = new Brick(b);
                
                brick.BrickChanged += OnBrickChanged;
                
                await brick.ConnectAsync();
                
                HashLabel.Content= brick.GetHashCode().ToString();
                portA.portId = brick.GetHashCode().ToString();
                portB.portId = brick.GetHashCode().ToString();
                portC.portId = brick.GetHashCode().ToString();
                portD.portId = brick.GetHashCode().ToString();
                portOne.portId = brick.GetHashCode().ToString();
                portTwo.portId = brick.GetHashCode().ToString();
                portThree.portId = brick.GetHashCode().ToString();
                portFour.portId = brick.GetHashCode().ToString();
                
                await brick.DirectCommand.PlayToneAsync(100, 1000, 300);

            }
            catch(Exception exc) {
                MessageBox.Show("Tento port se neshoduje s odchozím portem pro EV3 nebo jste již připojen. \n\n" + exc.ToString());
            }
        }
        
        public static string GetPortForBHDevice()
        {
            ManagementObjectSearcher serialSearcher = new ManagementObjectSearcher("root\\CIMV2","SELECT * FROM Win32_SerialPort");
            var query = from ManagementObject s in serialSearcher.Get()
                        select new { Name = s["Name"], DeviceID = s["DeviceID"], PNPDeviceID = s["PNPDeviceID"] };

            var port = query.FirstOrDefault(p => ((string)p.PNPDeviceID).Contains("BTHENUM"));
            return (string)port.DeviceID;
        }

        private void stopButton2_Click(object sender, RoutedEventArgs e)
        {
            record2 = false;
            BlockTwo.Foreground = Brushes.Black;
        }

        private void stopButton3_Click(object sender, RoutedEventArgs e)
        {
            record3 = false;
            BlockThree.Foreground = Brushes.Black;
        }

        private void stopButton4_Click(object sender, RoutedEventArgs e)
        {
            record4 = false;
            BlockFour.Foreground = Brushes.Black;
        }

        private void stopButtonA_Click(object sender, RoutedEventArgs e)
        {
            recordA = false;
            BlockA.Foreground = Brushes.Black;
        }

        private void stopButtonB_Click(object sender, RoutedEventArgs e)
        {
            recordB = false;
            BlockB.Foreground = Brushes.Black;
        }

        private void stopButtonC_Click(object sender, RoutedEventArgs e)
        {
            recordC = false;
            BlockC.Foreground = Brushes.Black;
        }

        private void stopButtonD_Click(object sender, RoutedEventArgs e)
        {
            recordD = false;
            BlockD.Foreground = Brushes.Black;
        }

        private void zaznamButtonA_Click(object sender, RoutedEventArgs e)
        {
            recordA = true;
            /*swA.WriteLine("");
            swA.WriteLine("PortA : ");*/
            portA.portName = "PortA";
            brick.BrickChanged += BrickReaderA;
        }

        private void zaznamButtonB_Click(object sender, RoutedEventArgs e)
        {
            recordB = true;
            /*swB.WriteLine("");
            swB.WriteLine("PortB : ");*/
            portB.portName = "PortB";
            brick.BrickChanged += BrickReaderB;
        }

        private void zaznamButtonC_Click(object sender, RoutedEventArgs e)
        {
            recordC = true;
            /*
            swC.WriteLine("");
            swC.WriteLine("PortC : ");*/
            portC.portName = "PortC";
            brick.BrickChanged += BrickReaderC;
        }

        private void zaznamButtonD_Click(object sender, RoutedEventArgs e)
        {
            recordD = true;
            /*
            swD.WriteLine("");
            swD.WriteLine("PortD : ");*/
            portD.portName = "PortD";
            brick.BrickChanged += BrickReaderD;
        }

        private void zaznamButton2_Click(object sender, RoutedEventArgs e)
        {
            record2 = true;
            /*sw2.WriteLine("");
            sw2.WriteLine("PortTwo : ");*/
            portTwo.portName = "PortTwo";
            brick.BrickChanged += BrickReader2;
        }

        private void zaznamButton3_Click(object sender, RoutedEventArgs e)
        {
            record3 = true;
            /*sw3.WriteLine("");
            sw3.WriteLine("PortThree : ");*/
            portThree.portName = "PortThree";
            brick.BrickChanged += BrickReader3;
        }

        private void zaznamButton4_Click(object sender, RoutedEventArgs e)
        {
            record4 = true;
            /*sw4.WriteLine("");
            sw4.WriteLine("PortFour : ");*/
            portFour.portName = "PortFour";
            brick.BrickChanged += BrickReader4;
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            try
            {
                brick.Disconnect();
            }
            catch { }
        }

        private void radioButton_Checked(object sender, RoutedEventArgs e)
        {
            
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            if (radioButton.IsChecked == true) {
                target = true;
            } else {
                target = false;
            }
        }


    }

}
