﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft;


namespace UnitTest
{
    class Class1
    {
        
        


        public string recording(Value portOne, Value portTwo)
        {
            string json = "{'data':[";

            if (portOne.portName != null && portOne.portValue != null) { json += Newtonsoft.Json.JsonConvert.SerializeObject(portOne) + ","; }
            if (portTwo.portName != null && portTwo.portValue != null) { json += Newtonsoft.Json.JsonConvert.SerializeObject(portTwo) + ","; }

            json = json.Remove(json.Length - 1);
            json += "]}";

            if (json != "{'data':]}")
            {
                return json;
            }
            else
            {
                return null;
            }
        }
        }
}
