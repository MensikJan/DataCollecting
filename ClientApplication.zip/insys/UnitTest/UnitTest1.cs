﻿using System;
using NUnit.Framework;
using insys;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Class1 recordMethod = new Class1();
            Value portOne = new Value();
            Value portTwo = new Value();
            portOne.portId = "10";
            portOne.portName = "portOne";
            portOne.portTime = "10.10.2015";
            portOne.portValue = "10001";

            portTwo.portId = "10";
            portTwo.portName = "portOne";
            portTwo.portTime = "10.10.2015";
            portTwo.portValue = "10001";

            String result = recordMethod.recording(portOne, portTwo);
            String optimalResult = "{'data':[{\"portId\":\"10\",\"portName\":\"portOne\",\"portTime\":\"10.10.2015\",\"portValue\":\"10001\"},{\"portId\":\"10\",\"portName\":\"portOne\",\"portTime\":\"10.10.2015\",\"portValue\":\"10001\"}]}";

            NUnit.Framework.Assert.AreEqual(optimalResult, result);
            NUnit.Framework.Assert.AreEqual(null, null);
        }
    }
}
